public interface IConnect {
  public boolean makeConnection();
}
