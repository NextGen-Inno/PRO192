public interface IConnect {
    
    boolean makeConnection();
}
